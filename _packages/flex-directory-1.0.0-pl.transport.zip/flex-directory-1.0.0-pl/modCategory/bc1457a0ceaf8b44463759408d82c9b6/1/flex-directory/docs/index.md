# Flex Directory SPA

MODX 2.4 Flexbox Directory configured as a Single Page Application.

1. Change the Home Template and Default Template to FDSPA Page
