# Flex Directory SPA 1.0.0
- Basic Package with Grid CSS, Snippets, Chunks, System Settings.
