# Flex Directory SPA 1.1.0
- Added Search
- New Design
- Ajax Modal Content
- Mobile Menu

# Flex Directory SPA 1.0.0
- Basic Package with Grid CSS, Snippets, Chunks, System Settings.
